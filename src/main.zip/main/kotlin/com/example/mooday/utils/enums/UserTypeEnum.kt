package com.example.mooday.utils.enums

enum class UserTypeEnum { ADULT, CHILD }
