INSERT INTO family (nameFamily) VALUES ('Girard');
INSERT INTO family (nameFamily) VALUES ('Mikos');
INSERT INTO family (nameFamily) VALUES ('Barraud');
INSERT INTO family (nameFamily) VALUES ('Dupont');
INSERT INTO family (nameFamily) VALUES ('Lebeau');
